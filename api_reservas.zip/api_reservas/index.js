const http = require('http');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const PORT = 3000;

const readJSON = (filePath) => {
  return JSON.parse(fs.readFileSync(filePath));
};

const writeJSON = (filePath, data) => {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json');

  // Esto imprimirá exactamente la URL que recibe el servidor
  console.log(`Petición recibida: Método: ${req.method}, URL: ${req.url}`);

  if (req.method === 'GET' && req.url === '/rooms') {
    const rooms = readJSON('rooms.json');
    res.writeHead(200);
    return res.end(JSON.stringify(rooms));
  }

  if (req.method === 'GET' && req.url === '/reservations') {
    const reservations = readJSON('reservations.json');
    res.writeHead(200);
    return res.end(JSON.stringify(reservations));
  }

  if (req.method === 'POST' && req.url === '/reservations') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const { roomId, user, timeSlot, peopleCount } = JSON.parse(body);
      const rooms = readJSON('rooms.json');
      const reservations = readJSON('reservations.json');

      const room = rooms.find(r => r.id === roomId);
      if (!room) {
        res.writeHead(404);
        return res.end(JSON.stringify({ error: 'Sala no encontrada.' }));
      }

      if (peopleCount > room.capacity) {
        res.writeHead(400);
        return res.end(JSON.stringify({ error: 'Capacidad superada.' }));
      }

      const conflict = reservations.some(r => r.roomId === roomId && r.timeSlot === timeSlot);
      if (conflict) {
        res.writeHead(400);
        return res.end(JSON.stringify({ error: 'Horario ya reservado.' }));
      }

      const newReservation = { id: uuidv4(), roomId, user, timeSlot, peopleCount };
      reservations.push(newReservation);
      writeJSON('reservations.json', reservations);

      res.writeHead(201);
      res.end(JSON.stringify(newReservation));
    });
    return;
  }

  if (req.method === 'DELETE' && req.url.startsWith('/reservations/')) {
    const reservationId = req.url.split('/')[2];
    let reservations = readJSON('reservations.json');

    const reservationIndex = reservations.findIndex(r => r.id === reservationId);
    if (reservationIndex === -1) {
      res.writeHead(404);
      return res.end(JSON.stringify({ error: 'Reserva no encontrada.' }));
    }

    reservations.splice(reservationIndex, 1);
    writeJSON('reservations.json', reservations);

    res.writeHead(204);
    return res.end();
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Ruta no encontrada.' }));
});

server.listen(PORT, () => {
  console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
